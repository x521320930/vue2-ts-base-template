
### 本地开发环境

```npm
npm run serve
```

### 部署测试环境

```npm
npm run build:test
```

### 部署生产环境

```npm
npm run build:prd
```

### Vue-Cli 文档

See [Configuration Reference](https://cli.vuejs.org/config/).


### gitTS项目整合 start
 
  [夜尽天明](https://github.com/biaochenxuying/blog-vue-typescript)

  [Chong Guo](https://github.com/Armour/vue-typescript-admin-template)

  [Simon Zhang](vue-typescript-dpapp-demo)  