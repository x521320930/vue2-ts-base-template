/**
 * @describe API接口
 */

export interface Api {
  pensionYears: any,
  pensionCity: any,
  pensionCalculator: any,
  pensionStartPlan: any,
  [key: string]: any;
}