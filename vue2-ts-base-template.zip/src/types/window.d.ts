/**
 * @author  x521320930@gmail.com
 * @describe 对window 进行声明
 */

// eslint-disable-next-line no-var
declare var TDAPP: any

// eslint-disable-next-line no-var
declare var clipboardData: DataTransfer

// eslint-disable-next-line no-var
declare var WVJBCallbacks: any

// eslint-disable-next-line no-var
declare var WebViewJavascriptBridge: any

// eslint-disable-next-line no-var
declare var wx: any

// eslint-disable-next-line no-var
declare var sensors: any

// eslint-disable-next-line no-var
declare var viewWillAppear: any

// eslint-disable-next-line no-var
declare var _loadingRequestCount: any
