/**
 * @author  x521320930@gmail.com
 * @description 通用的变量
 */

