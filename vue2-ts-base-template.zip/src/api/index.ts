/**
 * @author  x521320930@gmail.com
 * @describe 接口入口
 */

import * as pension from './modules/pension'

export default {
  ...pension
}
