/**
 * @author  x521320930@gmail.com
 * @describe utils/config 接口存放处
 */

/**
 * @describe 对环境配置进行约束
 */
export interface EntryNodeEnvInterface {
  readonly [propName: string]: any;
}
