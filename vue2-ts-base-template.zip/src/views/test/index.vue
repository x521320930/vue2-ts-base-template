
<template>
  <div>dasdasdasdas</div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
@Component({
  name: 'Test'
})
export default class Test extends Vue {
  // 微信appid
  private wx_appid = ''
}
</script>
